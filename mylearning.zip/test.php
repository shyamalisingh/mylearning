<?php
$test="3.5seconds";
settype($test,"double");
settype($test,"integer");
settype($test,"string");
print($test);
?>